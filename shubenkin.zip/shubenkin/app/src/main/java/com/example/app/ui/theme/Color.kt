package com.example.app.ui.theme

import androidx.compose.ui.graphics.Color

val Teal80 = Color(0xFF64FFDA)
val Cyan80 = Color(0xFF18FFFF)
val Amber80 = Color(0xFFFFD740)

val Teal40 = Color(0xFF00897B)
val Cyan40 = Color(0xFF00ACC1)
val Amber40 = Color(0xFFFFA000)
